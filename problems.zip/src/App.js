import React, { useState } from "react";
import Header from "./components/Header";
import Header2 from "./components/Header2";
import Average from "./components/Average";
import Velocity from "./components/Velocity";
import Acceleration from "./components/Accelaration";
import AreaRectangle from "./components/AreaRectangle";
import Percentage from "./components/Percentage";
import SaleTax from "./components/SaleTax";
import TimeConvertion from "./components/TimeConvertion";
import CentripetalForce from "./components/CentripetalForce";
import ValueA from "./components/ValueA";
import DistanceCalculator from "./components/DistanceCalculator";
import AFormula from "./components/AFormula";
import EValue from "./components/EValue";
import AValue from "./AValue";
import AbsoluteDifference from "./components/AbsoluteDiffirence";
import SmallerLarger from "./components/SmallerLarger";
import NegativePositive from "./components/NegativePositive";
import MultiplyDiffirence from "./components/MultiplyDiffirence";
import SumCheck from "./components/SumCheck";
import ThirdNumber from "./components/ThirdNumber";
import DivideNumber from "./components/DivideNumber";
import PassedFailed from "./components/PassedFailed";
import DivideMultiply from "./components/DivideMultiply";
import ProblemNo27 from "./components/ProblemNo27";
import ProblemNo29 from "./components/ProblemNo29";
import ProblemNo26 from "./components/ProblemNo26";
import ProblemNo30 from "./components/.ProblemNo30";
import ProblemNo31 from "./components/ProblemNo31";
import ProblemNo32 from "./components/ProblemNo32";
import ProblemNo33 from "./components/ProblemNo33";
import ProblemNo34 from "./components/ProblemNo34";
import ProblemNo35 from "./components/ProblemNo35";
import ProblemNo36 from "./components/ProblemNo36";
import ProblemNo37 from "./components/ProblemNo37";
import ProblemNo38 from "./components/ProblemNo38";
import ProblemNo39 from "./components/ProblemNo39";
import ProblemNo40 from "./components/ProblemNo40";
import ProblemNo41 from "./components/ProblemNo41";
import ProblemNo42 from "./components/ProblemNo42";
import ProblemNo43 from "./components/ProblemNo43";
import ProblemNo44 from "./components/ProblemNo44";
import ProblemNo45 from "./components/ProblemNo45";
import ProblemNo46 from "./components/ProblemNo46";
import ProblemNo47 from "./components/ProblemNo47";
import ProblemNo48 from "./components/ProblemNo48";
import ProblemNo49 from "./components/ProblemNo49";
import ProblemNo50 from "./components/ProblemNo50";
import ProblemNo51 from "./components/ProblemNo51";
import ProblemNo52 from "./components/ProblemNo52";
import ProblemNo53 from "./components/ProblemNo53";
import ProblemNo54 from "./components/ProblemNo54";
import ProblemNo55 from "./components/ProblemNo55";
import ProblemNo56 from "./components/ProblemNo56";

function App() {
  return (
    <>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          paddingLeft: 30,
          paddingTop: 10,
          justifyContent: "space-around",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-around",
          }}
        >
          <Header />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-around",
          }}
        >
          <Header2 />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-around",
          }}
        >
          <Average />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-around",
          }}
        >
          <Velocity />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-around",
          }}
        >
          {" "}
          <Acceleration />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-around",
          }}
        >
          {" "}
          <AreaRectangle />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-around",
          }}
        >
          <Percentage />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-around",
          }}
        >
          {" "}
          <SaleTax />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-around",
          }}
        >
          <TimeConvertion />
        </div>

        <div
          style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}
        >
          {" "}
          <CentripetalForce />
        </div>
        <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ValueA/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><DistanceCalculator/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }} ><AFormula/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><EValue/></div>
          <div  style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><AValue/></div>
          <div  style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><AbsoluteDifference/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><SmallerLarger/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><NegativePositive/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><MultiplyDiffirence/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><SumCheck/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ThirdNumber/></div>
          <div  style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><DivideNumber/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><PassedFailed/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><DivideMultiply/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo27/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo29/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo26/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo30/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo31/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo32/></div>
          
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}> <ProblemNo33/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo34/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo35/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo36/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo37/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo38/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo39/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo40/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo41/></div>
          <div  style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo42/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }} ><ProblemNo43/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }} ><ProblemNo44/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo45/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo46/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo47/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo48/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo49/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo50/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo51/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo52/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo53/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo54/></div>
          <div style={{
            flexDirection: "column",
            paddingLeft: 30,
            paddingTop: 10,
            justifyContent: "space-between",
          }}><ProblemNo55/></div>
          <div><ProblemNo56/></div>

        

      </div>
    </>
  );
}

export default App;
